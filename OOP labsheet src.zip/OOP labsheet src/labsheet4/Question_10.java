/**
 * Labsheet 4
 * Question 10
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

public class Question_10 {
	public static void main(String[] args) {
		int[] arr = {5,3,7,2,1,34,10,34,2,4};
		System.out.println(getLargest(arr, 4));
	}
	
	public static int getLargest(int[] x, int n) {
		// check if n is not greater than the size of the array
		// if greater, assign the size of the array to n
		if (n > x.length) 
			n = x.length;
		
		int largest = x[0];
		for (int i = 1; i < n; i++) {
			if (x[i] > largest)
				largest = x[i];
		}
		return largest;
	}
}
