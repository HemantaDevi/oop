/**
 * Labsheet 4
 * Question 2
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

public class Question_2 {
	public static void main(String[] args) {
		int[] arr = new int[5];
		
		// Add odd numbers to array
		int odd = 1;
		for (int i = 0; i < arr.length; i++) {
			arr[i] = odd;
			odd = odd + 2;
		}
		
		// display array
		for (int j = 0; j < arr.length; j++) {
			System.out.println(arr[j]);
		}
	}
}
