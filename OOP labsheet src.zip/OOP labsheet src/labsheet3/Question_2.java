/**
 * Labsheet 3
 * Question 2
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_2 {
	public static void main(String[] args) {
		int x = 0;
		int n = 0;
		long result = 0;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter first number: ");
		x = input.nextInt();
		
		System.out.print("Enter by how much the number should be raised: ");
		n = input.nextInt();
		
		// calculate x power n
		result = calPower(x, n);
		System.out.println(x + " raised to the power of " + n + " = " + result);
		
		input.close();
	}
	
	/*
	 * Method to calculate x power n
	 */
	public static long calPower(int x, int n) {
		long result = 1;
		
		for (int i = 0; i < n; i++) {
			result = result * x;
		}
		
		return result;
	}
}
