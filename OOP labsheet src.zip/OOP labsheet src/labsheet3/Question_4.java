
/**
 * Labsheet 3
 * Question 4
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_4 {
	public static void main(String[] args) {
		int a = 0;
		int b = 0;
		int result = 0;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter first number: ");
		a = input.nextInt();
		
		System.out.print("Enter second number: ");
		b = input.nextInt();
		
		// calculate x power n
		result = cal(a,b);
		System.out.println(a + "^2 + " + b + "^2 = " + result);
		
		input.close();
	}
	
	/*
	 * inputs: x and y
	 * return x^2 + y^2
	 */
	public static int cal(int x, int y) {
		return (x * x) + (y * y);
	}
}
