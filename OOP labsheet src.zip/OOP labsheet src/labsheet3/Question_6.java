/**
 * Labsheet 3
 * Question 6
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_6 {
	public static void main(String[] args) {
		short height = 0;
		short width = 0;
		char symbol = ' ';
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter -1 for height or width to exit program");
		// Get symbol
		System.out.print("Enter symbol: ");
		symbol = input.nextLine().charAt(0);
		
		// Get height and width
		System.out.print("Enter height: ");
		height = input.nextShort();
		System.out.print("Enter width: ");
		width = input.nextShort();
		input.nextLine(); // consume nextLine character
		
		while (height != -1 && width != -1) {
			// print rectangle
			printRectangle(symbol, height, width);
			System.out.println();
			
			
			// Prompt user again for input
			System.out.println("Enter -1 for height or width to exit program");
			System.out.print("Enter symbol: ");
			symbol = input.nextLine().charAt(0);
			
			// Get height and width
			System.out.print("Enter height: ");
			height = input.nextShort();
			System.out.print("Enter width: ");
			width = input.nextShort();
			input.nextLine(); // consume nextLine character
		}
		
		System.out.println("End of program");
		input.close();
	}
	
	public static void printRectangle(char symbol, short height, short width) {
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				System.out.print(symbol);
			}
			System.out.println();
		}
	}
}
