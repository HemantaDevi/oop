/**
 * Labsheet 3
 * Question 1
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

public class Question_1 {
	public static void main(String[] args) {
		// Part (i)
		System.out.println("Part i: ");
		System.out.println(calSum(3));
		
		// Part (ii) 
		System.out.println();
		System.out.println("Part ii: ");
		System.out.println(isEven(10));
		System.out.println(isEven(19));
		
		// Part (iii) 
		System.out.println();
		System.out.println("Part iii: ");
		System.out.println(isOdd(10));
		System.out.println(isOdd(19));
	}
	
	
	/*
	 * Part (i)
	 */
	public static int calSum(int n) {
		int sum = 0;
		
		for (int  i = 1; i <= n; i++) {
			sum = sum + i;
		}
		
		return sum;
	}
	
	
	/*
	 * Part (ii)
	 */
	public static boolean isEven(int n) {
		if (n % 2 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/*
	 * Part (iii)
	 */
	public static boolean isOdd(int n) {
		if (n % 2 == 0) {
			return false;
		}
		else {
			return true;
		}
	}
}
