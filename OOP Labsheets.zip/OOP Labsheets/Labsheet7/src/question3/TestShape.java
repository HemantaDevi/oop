package question3;

public class TestShape {
	public static void main(String[] args) {
		// Create Square Objects
		Square square1 =new Square();
		Square square2 = new Square(5);
		Square square3 = new Square(10, "red", false);
		
		// Display square objects
		System.out.println("Square Objects: ");
		System.out.println(square1);
		System.out.println(square2);
		System.out.println(square3);
		System.out.println();
		
		// Display Area and perimeter
		System.out.println("Area and Perimeter:");
		System.out.println("Square 1 (Area) = " + square1.getArea() + " Square 1 (Perimeter) = " + square1.getPerimeter());
		System.out.println("Square 2 (Area) = " + square2.getArea() + " Square 2 (Perimeter) = " + square2.getPerimeter());
		System.out.println("Square 3 (Area) = " + square3.getArea() + " Square 3 (Perimeter) = " + square3.getPerimeter());
		System.out.println();
		
		// Modify sides and width and length
		square1.setSide(20);
		square2.setWidth(20);
		square3.setLength(20);
		
		// Display new area and perimeter
		System.out.println("New Area and Perimeter:");
		System.out.println("Square 1 (Area) = " + square1.getArea() + " Square 1 (Perimeter) = " + square1.getPerimeter());
		System.out.println("Square 2 (Area) = " + square2.getArea() + " Square 2 (Perimeter) = " + square2.getPerimeter());
		System.out.println("Square 3 (Area) = " + square3.getArea() + " Square 3 (Perimeter) = " + square3.getPerimeter());
	}
}
