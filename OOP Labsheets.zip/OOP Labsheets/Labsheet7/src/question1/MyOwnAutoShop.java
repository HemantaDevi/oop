package question1;

public class MyOwnAutoShop {
	public static void main(String[] args) {
		Sedan sedan1 = new Sedan(25, 100, 1000, "red");
		Ford ford1 = new Ford(2018, 10, 150, 3000, "blue");
		Ford ford2 = new Ford(2017, 20, 150, 2000, "yellow");
		Car car1 = new Car(200, 500, "green");
		
		System.out.println("Sedan1: " + sedan1.getSalePrice());
		System.out.println("Ford1: " + ford1.getSalePrice());
		System.out.println("Ford2: " + ford2.getSalePrice());
		System.out.println("Car1: " + car1.getSalePrice());
	}
}
