package question1;

public class Sedan extends Car {
	private int length;
	
	public Sedan(int length, int speed, double regularPrice, String color) {
		super(speed, regularPrice, color);
		this.length = length;
	}
	
	public double getSalePrice() {
		if (this.length > 20)
			super.regularPrice = super.getSalePrice() * 0.95;
		else
			super.regularPrice = super.getSalePrice() * 0.9;
		
		return super.getSalePrice();
	}
}
