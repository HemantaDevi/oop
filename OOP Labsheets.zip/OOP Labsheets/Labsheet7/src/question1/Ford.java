package question1;

public class Ford extends Car {
	private int year;
	private int manufacturerDiscount;
	
	public Ford(int year, int manufacturerDiscount, int speed, double regularPrice, String color) {
		super(speed, regularPrice, color);
		this.year = year;
		this.manufacturerDiscount = manufacturerDiscount;
	}
	
	public double getSalePrice() {
		super.regularPrice = super.getSalePrice() * (1 - ((double)this.manufacturerDiscount / 100));
		return super.getSalePrice();
	}
}
