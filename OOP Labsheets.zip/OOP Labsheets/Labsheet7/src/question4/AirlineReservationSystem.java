package question4;

import java.util.Scanner;

public class AirlineReservationSystem extends ReservationSystem {
	public final static int CAPACITY = 10;
	private int smokingRemainingSeats;
	private int nonSmokingRemainingSeats;
	
	public AirlineReservationSystem() {
		super(AirlineReservationSystem.CAPACITY);
		this.smokingRemainingSeats = 5;
		this.nonSmokingRemainingSeats = 5;
	}
	
	
	/* Method to check if smoking seats are full or not */
	public boolean isSmokingFull() {
		if (this.smokingRemainingSeats <= 0)
			return true;
		else
			return false;
	}
	
	
	/* Method to check if non-smoking seats are full or not */
	public boolean isNonSmokingFull() {
		if (this.nonSmokingRemainingSeats <= 0)
			return true;
		else
			return false;
	}
	
	
	/* Method to book smoking area */
	private void assignSmoking(int[] seats) {
		for (int i = 0; i < 5; i++) {
			if (seats[i] == 0) {
				seats[i] = 1;
				this.smokingRemainingSeats--;
				System.out.println("Reservation to smoking area successful");
				System.out.println("Seat No: " + (i + 1) + " Type: Smoking");
				return;
			}
		}
	}
	
	
	/* Method to book non-smoking area */
	private void assignNonSmoking(int[] seats) {
		for (int i = 5; i < 10; i++) {
			if (seats[i] == 0) {
				seats[i] = 1;
				this.nonSmokingRemainingSeats--;
				System.out.println("Reservation to non smoking area successful");
				System.out.println("Seat No: " + (i + 1) + " Type: Non Smoking");
				return;
			}
		}
	}
	
	/* 
	 * Method to assign seats 
	 * Returns true if successful else false
	 */
	public void assignSeat() {
		// Prompt user to enter a seat Type
		int seatType = 0;
		Scanner input = new Scanner(System.in);
		System.out.println("Please type 1 for smoking");
		System.out.println("Please type 2 for non-smoking");
		System.out.print("Type Here: ");
		seatType = input.nextInt();
		
		int[] seats = super.getSeats();
		
		// Handle smoking area request
		if (seatType == 1) {
			// Check if the smoking is full or not
			if (!isSmokingFull()) {
				
				// Look for a seat to book
				assignSmoking(seats);
			}
			else {
				// check if non-smoking area is also not full
				if (!isNonSmokingFull()) {
					System.out.println("Smoking Section Full");
					System.out.print("Do you want to move to Non-Smoking Area: ");
					input.nextLine();
					String answer = input.nextLine();
					
					if (answer.equals("yes")) {
						assignNonSmoking(seats);
					}
					else {
						System.out.println("Next Flight Leaves in 3 Hours");
					}
				}
				else {
					System.out.println("All Seats have been Booked");
				}
			}
		}
		
		
		// Handle non-smoking area request
		if (seatType == 2) {
			// Check if the non-smoking is full or not
			if (!isNonSmokingFull()) {
				// Look for a seat to book
				assignNonSmoking(seats);
			}
			else {
				// check if smoking area is also not full
				if (!isSmokingFull()) {
					System.out.println("Non Smoking Section Full");
					System.out.print("Do you want to move to Smoking Area: ");
					input.nextLine();
					String answer = input.nextLine();
					
					if (answer.equals("yes")) {
						assignSmoking(seats);
					}
					else {
						System.out.println("Next Flight Leaves in 3 Hours");
					}
				}
				else {
					System.out.println("All Seats have been Booked");
				}
			}
		}
		
	}
}
