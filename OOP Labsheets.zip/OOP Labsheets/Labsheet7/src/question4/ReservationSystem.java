package question4;

import java.util.Scanner;

public class ReservationSystem {
	private int capacity;
	private int[] seats;
	private int remainingSeats;
	
	
	public ReservationSystem(int capacity) {
		this.remainingSeats = capacity;
		this.capacity = capacity;
		this.seats = new int[capacity];
		
		// Put zero in all elements of the seats array (java does it automatically but it is mentioned in the question)
		for (int i = 0; i < this.seats.length; i++) {
			this.seats[i] = 0;
		}
	}
	
	
	/* Method to get the seats array */
	public int[] getSeats() {
		return this.seats;
	}
	
	/* Method to read capacity */
	public int getCapacity() {
		return this.capacity;
	}
	
	/* Method to assign capacity */
	public void setCapacity(int capacity) {
		this.remainingSeats = capacity;
		this.capacity = capacity;
		this.seats = new int[this.capacity];
		
		// Put zero in all elements of the seats array (java does it automatically but it is mentioned in the question)
		for (int i = 0; i < this.seats.length; i++) {
			this.seats[i] = 0;
		}
	}
	
	
	/* Method to read remaining seats */
	public int getRemainingSeats() {
		return this.remainingSeats;
	}
	
	
	/* Method to read if seats are all reserved */
	public boolean isFull() {
		if (this.remainingSeats <= 0)
			return true;
		else
			return false;
	}
	
	/* 
	 * Method to assign seats 
	 * Returns true if successful else false
	 */
	public void assignSeat() {
		// Prompt user to enter a seatNo
		int seatNo = 0;
		Scanner input = new Scanner(System.in);
		System.out.print("Please enter a seat number: ");
		seatNo = input.nextInt();
		input.close();
		
		// Check if there is still remaining seats
		if (!isFull()) {
			// Return false if seatNo exceeds the capacity
			if (seatNo >= this.seats.length)
				System.out.println("Wrong Seat Number");
			
			// If seat is empty, assign the seat
			if (this.seats[seatNo] == 0) {
				this.seats[seatNo] = 1;
				this.remainingSeats--;
				System.out.println("Seat Reserved Successfully");
			}
			else {
				System.out.println("Seat already Reserved");
			}
		}
		else
			System.out.println("All Seats Booked");
	}
}
