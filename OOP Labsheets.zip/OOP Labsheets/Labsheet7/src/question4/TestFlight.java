package question4;

public class TestFlight {
	public static void main(String[] args) {
		AirlineReservationSystem x = new AirlineReservationSystem();
		
		for (int i = 0; i < 12; i++) {
			x.assignSeat();
			System.out.println();
		}
	}
}
