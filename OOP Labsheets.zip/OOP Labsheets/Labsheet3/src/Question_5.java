/**
 * Labsheet 3
 * Question 5
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_5 {
	public static void main(String[] args) {
		int num = 0;
		int result = 0;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter an integer: ");
		num = input.nextInt();
		
		result = calFactorial(num);
		System.out.println("Factorial of " + num + " is " + result);
		input.close();
	}
	
	/*
	 * Factorial using recursion
	 */
	public static int calFactorial(int n) {
		if (n == 0) 
			return 1;
		else
			return n * calFactorial(n - 1);
	}
	
	
	/*
	 * Factorial without recursion
	 */
	public static int calFactorialWithoutRecursion(int n) {
		int result = 1;
		
		for (int i = n; i >=1; i--) {
			result = result * i;
		}
		
		return result;
	}
}
