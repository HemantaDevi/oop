/**
 * Labsheet 3
 * Question 8
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_8 {
	public static void main(String[] args) {
		double num1 = 0;
		double num2 = 0;
		short option = 0;
		double result = 0;
		Scanner input = new Scanner(System.in);
		
		// Display Menu
		MyCalculator.displayMenu();
		// Check what operation to perform
		System.out.print("Option: ");
		option = input.nextShort();
		
		while(option != 5) {
			// Prompt user for numbers
			System.out.print("Enter first numnber: ");
			num1 = input.nextDouble();
			System.out.print("Enter second number: ");
			num2 = input.nextDouble();
			
			switch(option) {
			case 1:
				result = MyCalculator.add(num1, num2);
				break;
			case 2:
				result = MyCalculator.substract(num1, num2);
				break;
			case 3:
				result = MyCalculator.mul(num1, num2);
				break;
			case 4:
				result = MyCalculator.div(num1, num2);
				break;
			}
			
			// Display Result
			System.out.println("Result: " + result);
			System.out.println();
			
			// Display Menu
			MyCalculator.displayMenu();
			// Check what operation to perform
			System.out.print("Option: ");
			option = input.nextShort();
		}
		
		System.out.println("End of program");
		input.close();
	}
}


class MyCalculator {
	/*
	 * Calculate sum of 2 numbers
	 */
	public static double add(double x, double y) {
		return x + y;
	}
	
	/*
	 * Calculate difference of 2 numbers
	 */
	public static double substract(double x, double y) {
		return x - y;
	}
	
	/*
	 * Calculate product of 2 numbers
	 */
	public static double mul(double x, double y) {
		return x * y;
	}
	
	/*
	 * Calculate division of 2 numbers
	 */
	public static double div(double x, double y) {
		return x / y;
	}
	
	/*
	 * Display Menu
	 */
	public static void displayMenu() {
		System.out.println("1. \t Add");
		System.out.println("2. \t Subtract");
		System.out.println("3. \t Multiply");
		System.out.println("4. \t Divide");
		System.out.println("5. \t Exit");
	}
}