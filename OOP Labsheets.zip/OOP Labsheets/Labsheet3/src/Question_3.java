/**
 * Labsheet 3
 * Question 3
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

public class Question_3 {
	public static void main(String[] args) {
		System.out.println(isEven(10));
		System.out.println(isEven(5));
	}
	
	/*
	 * Method to check if number is even or not
	 */
	public static boolean isEven(int n) {
		if (n % 2 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
}
