/**
 * Labsheet 4
 * Question 7
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_7 {
	public static void main(String[] args) {
		// Assume there are 5 students
		int[] students = new int[5];
		float[] marks = new float[5];
		Scanner input = new Scanner(System.in);
		
		int student_id = 0;
		float average_marks = 0.0f;
		
		float highest_marks = 0.0f;
		float lowest_marks = 0.0f;
		int highest_mark_index = 0;
		int lowest_mark_index = 0;
		
		// Enter student id and marks
		for (int i = 0; i < students.length; i++) {
			// Get student id and check if valid
			// if not valid, ask user to reenter data for the current student
			do {
				System.out.print("Enter the id(701 - 799) for student " + (i+1) + " :");
				student_id = input.nextInt();
			}
			while (student_id < 701 || student_id > 799);
			students[i] = student_id;
			
			
			// Get student average mark and check valid
			// if not valid, ask user to reenter data for the current student
			do {
				System.out.print("Enter average mark(0.0 - 100.0) for student: " + (i+1) + " :");
				average_marks = input.nextFloat();
			}
			while (average_marks < 0.0 || average_marks > 100.0);
			marks[i] = average_marks;
		}
		
		
		// Determine highest and lowest score index
		highest_marks = lowest_marks = marks[0];
		for (int i = 1; i < marks.length; i++) {
			if (marks[i] > highest_marks) {
				highest_marks = marks[i];
				highest_mark_index = i;
			}
			
			if (marks[i] < lowest_marks) {
				lowest_marks = marks[i];
				lowest_mark_index = i;
			}
		}
		
		
		// Display student with highest and lowest marks
		System.out.println("Highest Marks scored by: " + students[highest_mark_index] + " with a score of : " + highest_marks);
		System.out.println("Lowest Marks scored by: " + students[lowest_mark_index] + " with a score of : " + lowest_marks);
		
		input.close();
	}
}
