/**
 * Labsheet 4
 * Question 9
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_9 {
	public static void main(String[] args) {
		int arr_size = 0;
		int[] arr1;
		int[] arr2;
		Scanner input = new Scanner(System.in);
		
		// Prompt user to enter size of each array
		System.out.print("Enter size of the arrays: ");
		arr_size = input.nextInt();
		
		// Set array size
		arr1 = new int[arr_size];
		arr2 = new int[arr_size];
		
		// Prompt user to insert values inside both array
		for (int i = 0; i < arr_size; i++) {
			System.out.print("Enter value for position " + (i + 1) + " in first array: ");
			arr1[i] = input.nextInt();
			System.out.print("Enter value for position " + (i + 1) + " in second array: ");
			arr2[i] = input.nextInt();
		}
		
		// Display sum of square of corresponding values inside both arrays
		sumSquareXY(arr1, arr2);
		
		input.close();
	}
	
	public static void sumSquareXY(int[] x, int[] y) {
		for (int i = 0; i < x.length; i++) {
			System.out.println(x[i] + "^2 + " + y[i] + "^2 = " + ((x[i] * x[i]) + (y[i] * y[i])));
		}
	}
}