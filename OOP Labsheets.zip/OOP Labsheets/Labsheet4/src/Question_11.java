/**
 * Labsheet 4
 * Question 11
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_11 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		// Assume maximum size is 50
		char[] c = new char[50];
		char inputChar;
		int counter = 0;
		
		// Prompt user to enter a sequence of characters until * is entered
		System.out.print("Enter a character (stop process by inserting (*):");
		inputChar = input.nextLine().charAt(0);
		
		while (inputChar != '*') {
			c[counter] = inputChar;
			counter++;
			
			System.out.print("Enter another character (stop process by inserting (*):");
			inputChar = input.nextLine().charAt(0);
		}
		
		// Display sequence of characters in reverse
		displayReverse(c);
		
		input.close();
	}
	
	public static void displayReverse(char[] c) {
		for (int i = c.length-1; i >= 0; i--) {
			// Don't print unset array elements
			if (c[i] != '\u0000') { 
				System.out.print(c[i]);
			}
		}
	}
}
