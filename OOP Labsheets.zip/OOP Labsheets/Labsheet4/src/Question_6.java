/**
 * Labsheet 4
 * Question 6
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_6 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num_integers = 0;
		int[] arr;
		int min = 0 ;
		int max = 0;
		
		// Prompt user to enter the number of elements to be inserted in the array
		System.out.print("Enter the number of elements to be inserted: ");
		num_integers = input.nextInt();
		
		// Set size of array
		arr = new int[num_integers];
		
		// Prompt user to enter values into the array
		for (int  i = 0; i < num_integers; i++) {
			System.out.print("Enter number for index: " + (i+1) + " :");
			arr[i] = input.nextInt();
		}
		
		// Determine maximum and minimum number in the array
		min = max = arr[0];
		for (int j = 1; j < num_integers; j++) {
			if (arr[j] < min) {
				min = arr[j];
			}
			
			if (arr[j] > max) {
				max = arr[j];
			}
		}
		
		// Display result
		System.out.println("Min: " + min);
		System.out.println("Max: " + max);
		
		input.close();
	}
}
