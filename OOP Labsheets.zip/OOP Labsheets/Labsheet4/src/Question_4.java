/**
 * Labsheet 4
 * Question 4
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_4 {
	public static void main(String[] args) {
		float[] sales = new float[12];
		float sum = 0.0f;
		float average = 0.0f;
		Scanner input = new Scanner(System.in);
		
		// Prompt to user to enter sales income for each month
		for (int i = 0; i < sales.length; i++) {
			System.out.print("Enter sales income for month: " + (i+1) + " : ");
			sales[i] = input.nextFloat();
		}
		
		// Calculate sum
		for (int j = 0; j < sales.length; j++) {
			sum = sum + sales[j];
		}
		
		// Calculate and display average
		average = sum / sales.length;
		System.out.println("Average : $" + (average * 1000));
		input.close();
	}
}
