/**
 * Labsheet 4
 * Question 5
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

import java.util.Scanner;

public class Question_5 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num_words = 0;
		int num_vowels = 0;
		
		// Input text
		System.out.print("Enter a text: ");
		String text = input.nextLine();
		
		// Check number of words
		num_words = text.length();
		
		
		// Convert text to lowercase
		text = text.toLowerCase();
		
		// Check number of vowels
		char currentChar;
		for (int i = 0; i < num_words; i++) {
			currentChar = text.charAt(i);
			
			// check if character is a vowel
			if (currentChar == 'a' || currentChar == 'e' || currentChar == 'i' || currentChar == 'o' || currentChar =='u') {
				num_vowels++;
			}
		}
		
		// Display results
		System.out.println("Number of words: " + num_words);
		System.out.println("Number of vowels: " + num_vowels);
		
		input.close();
	}
}
