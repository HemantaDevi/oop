/**
 * Labsheet 4
 * Question 3
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

public class Question_3 {
	public static void main(String[] args) {
		int[] arr = {1,3,5,7,9};
		
		// Display array
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
}
