/**
 * Labsheet 4
 * Question 1
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 26/02/2018
 */

public class Question_1 {
	public static void main(String[] args) {
		int[] arr = new int[5];
		
		for (int  i = 0;  i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
}
