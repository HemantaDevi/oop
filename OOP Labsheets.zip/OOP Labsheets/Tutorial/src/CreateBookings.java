/**
 * 
 * @author yoven ayassamy
 * @version 1.0
 * Tutorial Question 2
 *
 */

class RoomBooking {
	private String room_type;
	private int num_days;
	
	public RoomBooking(String room_type, int num_days) {
		this.room_type = room_type;
		this.num_days = num_days;
	}
	
	public void displayRoomDetails() {
		System.out.println("Room type: " + this.room_type);
		System.out.println("Num Days: " +  this.num_days);
	}
	
	public int getRoomCharge() {
		if (this.room_type.equals("Standard"))
			return 100 * this.num_days;
		
		else if (this.room_type.equals("Deluxe"))
			return 200 * this.num_days;
		
		else if (this.room_type.equals("Family"))
			return 400 * this.num_days;
		
		else
			return -1;
	}
	
	
}



class PanoramicRoomBooking extends RoomBooking {
	private String view_type;
	
	public PanoramicRoomBooking(String room_type, int num_days, String view_type) {
		super(room_type, num_days);
		this.view_type = view_type;
	}
	
	public void displayRoomDetails() {
		super.displayRoomDetails();
		System.out.println("View Type: " + this.view_type);
	}
	
	public int getRoomCharge() {
		if (this.view_type.equals("Garden"))
			return 20 + super.getRoomCharge();
		else if (this.view_type.equals("Pool"))
			return 30 + super.getRoomCharge();
		else if (this.view_type.equals("Sea"))
			return 50 + super.getRoomCharge();
		else
			return -1;
	}
}


public class CreateBookings {
	public static void main(String[] args) {
		RoomBooking[] roombookings = new RoomBooking[5];
		roombookings[0] = new RoomBooking("Standard", 2);
		roombookings[1] = new PanoramicRoomBooking("Family", 3, "Garden");
		roombookings[2] = new RoomBooking("Deluxe", 1);
		roombookings[3] = new PanoramicRoomBooking("Standard", 2, "Pool");
		roombookings[4] = new PanoramicRoomBooking("Deluxe", 5, "Sea");
		
		System.out.println(roombookings[1].getRoomCharge());
	}
}
