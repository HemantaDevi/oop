/**
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 *	Question 3
 */

interface Food {
	public int getCalories();
	public void setCalories(int calories);
}


abstract class Vegetable implements Food {
	protected String name;
	private int calories;
	
	public Vegetable(String name, int calories) {
		this.name = name;
		this.calories = calories;
	}
	
	public int getCalories() {
		return this.calories;
	}
	
	public void setCalories(int calories) {
		this.calories = calories;
	}
	
	abstract public void prepare();
}


class Cooked extends Vegetable {
	public final static int CALORIES_LOSS = 10;
	private String cookType;
	
	public Cooked(String cookType, String name, int calories) {
		super(name, calories);
		this.cookType = cookType;
	}

	public void prepare() {
		setCalories(getCalories() - CALORIES_LOSS);	
		System.out.println(cookType + " " + super.name + ". Calories left: " + getCalories()); // For clarity put super.name
	}
}



class Raw extends Vegetable {
	public Raw(String name, int calories) {
		super(name, calories);
	}
	
	public void prepare() {
		System.out.println("Slice " + super.name + ". Calories: " + getCalories());
	}
}



public class MainKitchen {
	public static void main(String[] args) {
		// Raw vegetable
		Raw raw = new Raw("Onion", 50);
		raw.prepare();
		
		// Cook vegetable
		Cooked cook = new Cooked("Boil", "Beetroot", 60);
		cook.prepare();
	}
}




