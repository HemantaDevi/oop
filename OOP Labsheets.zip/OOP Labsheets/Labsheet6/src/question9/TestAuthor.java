package question9;

public class TestAuthor {
	public static void main(String[] args) {
		Author author1 = new Author("yoven", "ayassamyyoven@hotmail.com", 'M');
		System.out.println(author1);
		author1.setEmail("ayassamyyoven@gmail.com");
		System.out.println(author1);
	}
}
