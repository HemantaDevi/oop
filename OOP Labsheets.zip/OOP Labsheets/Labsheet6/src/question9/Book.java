package question9;

public class Book {
	private String name;
	private Author author;
	private double price;
	private int qtyInStock;
	
	/* Constructors */
	public Book(String name, Author author, double price) {
		this.name = name;
		this.author = author;
		this.price = price;
	}
	
	public Book(String name, Author author, double price, int qtyInStock) {
		this.name = name;
		this.author = author;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}

	
	
	/* Getters and Setters */
	public String getName() {
		return name;
	}

	public Author getAuthor() {
		return author;
	}

	public double getPrice() {
		return price;
	}

	public int getQtyInStock() {
		return qtyInStock;
	}
	
	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}
	
	
	/* Overriding toString method inherited from Object class */
	public String toString() {
		return this.name + " by " + this.author;
	}	
	
	
	/* Getter method for information on the author */
	public String getAuthorName() {
		return this.author.getName();
	}
	
	public String getAuthorEmail() {
		return this.author.getEmail();
	}
	
	public char getAuthorGender() {
		return this.author.getGender();
	}
}
