package question9;

public class BookTest {
	public static void main(String[] args) {
		// Create author object
		Author yoven = new Author("yoven", "ayassamyyoven@gmail.com", 'M');
		
		// Create book object
		Book myBook = new Book("Java Programming", yoven, 19.99, 50);
		
		// Print book details
		System.out.println(myBook);
		
		// Get author details from book object
		System.out.println("Author Name: " + myBook.getAuthorName());
		System.out.println("Author Email: " + myBook.getAuthorEmail());
		System.out.println("Author Gender: " + myBook.getAuthorGender());
	}
}
