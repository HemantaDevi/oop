package question10;

public class TestMyCircle {
	public static void main(String[] args) {
		MyCircle circle1 = new MyCircle(5,4,10);
		MyCircle circle2 = new MyCircle(new MyPoint(5,3), 20);
		
		// Print Circle Details
		System.out.println(circle1);
		System.out.println(circle2);
		System.out.println();
		
		// Get Area
		System.out.println(circle1.getArea());
		System.out.println(circle2.getArea());
		System.out.println();
		
		// Modify center
		circle1.setCenter(new MyPoint(10,20)); //circle 1
		circle2.setCenterXY(30,60); // circle 2
		System.out.println(circle1);
		System.out.println(circle2);
		System.out.println();
		
	}
}
