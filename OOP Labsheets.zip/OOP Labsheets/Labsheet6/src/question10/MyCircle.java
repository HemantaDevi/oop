package question10;

public class MyCircle {
	private MyPoint center;
	private int radius;
	
	/* Constructors */
	public MyCircle(int x, int y, int radius) {
		this.center = new MyPoint(x,y);
		this.radius = radius;
	}
	
	public MyCircle(MyPoint center, int radius) {
		this.center = center;
		this.radius = radius;
	}
	
	/* Getters and Setters */
	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	public int setRadius() {
		return this.radius;
	}
	
	
	public MyPoint getCenter() {
		return this.center;
	}
	
	public void setCenter(MyPoint center) {
		this.center = center;
	}
	
	
	public int getCenterX() {
		return this.center.getX();
	}
	
	public int getCenterY() {
		return this.center.getY();
	}
	
	
	public void setCenterXY(int x, int y) {
		this.center.setX(x);
		this.center.setY(y);
	}
	
	
	public double getArea() {
		return Math.PI * this.radius * this.radius;
	}
	
	
	public String toString() {
		return "Circle @ (" + getCenterX() + "," + getCenterY() + ") radius=" + this.radius;
	}
}
