package question13;

public class TestBook {
	public static void main(String[] args) {
		Book myBook = new Book("Yoven's Book", 12.99, 20);
		
		// Add authors
		myBook.addAuthor(new Author("yoven", "aya@gmail.com", 'M'));
		myBook.addAuthor(new Author("sharana", "sha@gmail.com", 'F'));
		myBook.addAuthor(new Author("laurent", "lau@gmail.com", 'M'));
		
		// Print Book Details
		System.out.println("Book Details: ");
		System.out.println(myBook);
		System.out.println();
		
		// Print Authors
		System.out.println("Book Authors: ");
		myBook.printAuthors();
		System.out.println();
		
		
		System.out.println("----------------------------------------------------------------");
		
		
		// Remove an invalid author and print book details and authors
		if (myBook.removeAuthorByName("Devi")) 
			System.out.println("Removal Successful");
		else
			System.out.println("Removal Failed");
		
		System.out.println("Book Details: ");
		System.out.println(myBook);
		System.out.println();
		
		System.out.println("Book Authors: ");
		myBook.printAuthors();
		System.out.println();
		
		System.out.println("----------------------------------------------------------------");
		
		// Remove an valid author and print book details and authors
		if (myBook.removeAuthorByName("laurent")) 
			System.out.println("Removal Successful");
		else
			System.out.println("Removal Failed");
		
		System.out.println("Book Details: ");
		System.out.println(myBook);
		System.out.println();
		
		System.out.println("Book Authors: ");
		myBook.printAuthors();
		System.out.println();
		
	}
}
