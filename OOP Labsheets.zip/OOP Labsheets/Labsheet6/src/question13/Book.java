package question13;

public class Book {
	private String name;
	private Author[] authors = new Author[5];
	private int numAuthors = 0;
	private double price;
	private int qtyInStock = 0;
	
	public Book(String name, double price) {
		this.name = name;
		this.price = price;
	}
	
	public Book(String name, double price, int qtyInStock) {
		this.name = name;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}
	
	
	public String getName() {
		return this.name;
	}
	
	
	public Author[] getAuthors() {
		return this.authors;
	}
	
	
	public double getPrice() {
		return this.price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getQtyInStock() {
		return qtyInStock;
	}
	
	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}
	
	public String toString() {
		return this.name + " by " + this.numAuthors + " authors";
	}	
	
	public void printAuthors() {
		for (int i = 0; i < this.authors.length; i++) {
			// Check for null before printing
			if (this.authors[i] != null) {
				System.out.println(this.authors[i].getName());
			}
		}
	}
	
	/* Method to add author */
	public void addAuthor(Author author) {
		this.authors[this.numAuthors] = author;
		this.numAuthors++;
	}
	
	/* Method to remove author by name */
	public boolean removeAuthorByName(String authorName) {
		for (int i = 0; i < this.authors.length; i++) {
			// Check for null values
			if (this.authors[i] != null) {
				// If name is present inside the array, remove the Author object by setting the array current index content to null
				if (this.authors[i].getName().equals(authorName)) {
					this.authors[i] = null;
					this.numAuthors--;
					return true;
				}
			}
		}
		return false;
	}
}