package question1;

public class TestPizza {
	public static void main(String[] args) {
		Pizza pizza1 = new Pizza();
		pizza1.setDiameter(10);
		pizza1.setPrice(20.0);
		pizza1.setTopping("olive");
		
		Pizza pizza2 = new Pizza();
		pizza2.setDiameter(15);
		pizza2.setPrice(30.0);
		pizza2.setTopping("cheese");
		
		System.out.println("Pizza 1: ");
		System.out.println("Topping: " + pizza1.getTopping());
		System.out.println("Price: " + pizza1.getPrice());
		System.out.println("Diameter: " + pizza1.getDiameter());
		
		System.out.println();
		
		System.out.println("Pizza 2: ");
		System.out.println("Topping: " + pizza2.getTopping());
		System.out.println("Price: " + pizza2.getPrice());
		System.out.println("Diameter: " + pizza2.getDiameter());
	}
}
