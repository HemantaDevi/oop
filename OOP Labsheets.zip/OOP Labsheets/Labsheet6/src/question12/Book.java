package question12;

public class Book {
	private String name;
	private Author[] authors;
	private double price;
	private int qtyInStock = 0;
	
	public Book(String name, Author[] authors, double price) {
		this.name = name;
		this.authors = authors;
		this.price = price;
	}
	
	public Book(String name, Author[] authors, double price, int qtyInStock) {
		this.name = name;
		this.authors = authors;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}
	
	
	public String getName() {
		return this.name;
	}
	
	
	public Author[] getAuthors() {
		return this.authors;
	}
	
	
	public double getPrice() {
		return this.price;
	}
	
	public int getQtyInStock() {
		return qtyInStock;
	}
	
	public void setQtyInStock(int qtyInStock) {
		this.qtyInStock = qtyInStock;
	}
	
	public String toString() {
		return this.name + " by " + this.authors.length + " authors";
	}	
	
	public void printAuthors() {
		for (int i = 0; i < this.authors.length; i++) {
			System.out.println(this.authors[i].getName());
		}
	}
}
