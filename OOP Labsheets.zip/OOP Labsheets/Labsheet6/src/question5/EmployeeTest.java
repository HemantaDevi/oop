package question5;

public class EmployeeTest {
	public static void main(String[] args) {
		// Create Employee objects
		Employee emp1 = new Employee("yoven", "ayassamy", 6000);
		Employee emp2 = new Employee("Laurent", "Carpen", 10000);
		
		// Display yearly salary
		System.out.println(emp1.getFirstName() + " yearly salary: " + (emp1.getSalary() * 12));
		System.out.println(emp2.getFirstName() + " yearly salary: " + (emp2.getSalary() * 12));
		
		// 10% increase in salary to both employees
		emp1.setSalary(emp1.getSalary() * 1.1);
		emp2.setSalary(emp2.getSalary() * 1.1);
		System.out.println();
		
		// Display yearly salary
		System.out.println(emp1.getFirstName() + " yearly salary: " + (emp1.getSalary() * 12));
		System.out.println(emp2.getFirstName() + " yearly salary: " + (emp2.getSalary() * 12));
	}
}
