package question4;

public class Invoice {
	private String partNo;
	private String description;
	private int quantity;
	private double price;
	
	public Invoice(String partNo, String description, int quantity, double price) {
		this.partNo = partNo;
		this.description = description;
		this.quantity = quantity;
		this.price = price;
	}
	
	/* Getters and Setters */
	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		if (quantity < 0)
			this.quantity = 0;
		else
			this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		if (price < 0)
			this.price = 0.0;
		else
			this.price = price;
	}
	
	/* Method to calculate invoice amount */
	public double getInvoiceAmount() {
		return this.price * this.quantity;
	}
}
