package question4;

public class InvoiceTest {
	public static void main(String[] args) {	
		Invoice invoice1 = new Invoice("P000", "Part Description", 10, 2.5);
		System.out.println("Invoice Amount: " + invoice1.getInvoiceAmount());
	}
}
