package question14;

public class Book {
	private String name;
	private String	ISBN;
	private String authorName;
	private double price;
	
	public Book(String name, String iSBN, String authorName, double price) {
		this.name = name;
		ISBN = iSBN;
		this.authorName = authorName;
		this.price = price;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getBookInfo() {
		return "Book Name: " + this.name + "\nISBN: " + this.ISBN + "\nAuthor: " + this.authorName + "\nPrice: " + this.price;
	}
}
