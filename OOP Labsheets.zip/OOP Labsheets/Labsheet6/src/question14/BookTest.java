package question14;

public class BookTest {
	public static void main(String[] args) {
		double total = 0.0;
		
		Book[] books = new Book[5];
		books[0] = new Book("Book 1", "0000", "Author 1", 10);
		books[1] = new Book("Book 2", "0001", "Author 2", 20);
		books[2] = new Book("Book 3", "0002", "Author 3", 30);
		books[3] = new Book("Book 4", "0003", "Author 4", 40);
		books[4] = new Book("Book 5", "0004", "Author 5", 50);
		
		// Details of each books
		for (int i = 0; i < books.length; i++) {
			System.out.println(books[i].getBookInfo());
			System.out.println();
		}
		
		System.out.println();
		
		// Total Price
		for (int j = 0 ; j < books.length; j++) {
			total += books[j].getPrice();
		}
		System.out.println("Total Price: " + total);
	}
}
