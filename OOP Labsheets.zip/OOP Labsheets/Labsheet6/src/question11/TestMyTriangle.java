package question11;

public class TestMyTriangle {
	public static void main(String[] args) {
		
	}
}
