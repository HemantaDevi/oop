package question2;

public class TestCircle {
	public static void main(String[] args) {
		Circle circle1 = new Circle();
		Circle circle2 = new Circle();
		Circle circle3 = new Circle();
		
		circle1.setRadius(-10);
		circle2.setRadius(10);
		
		circle1.computeDiameter();
		circle1.computeArea();
		circle2.computeDiameter();
		circle2.computeArea();
		circle3.computeDiameter();
		circle3.computeArea();
		
		// Display Results
		circle1.displayInfo();
		System.out.println();
		circle2.displayInfo();
		System.out.println();
		circle3.displayInfo();
	}
}
