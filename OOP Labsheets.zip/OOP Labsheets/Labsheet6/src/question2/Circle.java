package question2;

public class Circle {
	private double radius;
	private double diameter;
	private double area;
	
	// Constructor to create a circle of radius = 1
	public Circle() {
		this.radius = 1;
	}
	
	// Radius getter method
	public double getRadius() {
		return this.radius;
	}
	
	// Radius setter method
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	// Method to compute diameter
	public double computeDiameter() {
		this.diameter =  this.radius * 2;
		return this.diameter;
	}
	
	// Method to compute area
	public double computeArea() {
		this.area =  3.14 * this.radius * this.radius;
		return this.area;
	}
	
	// Method to display info on circle
	public void displayInfo() {
		System.out.println("Radius: " + this.radius);
		System.out.println("Diameter: " + this.diameter);
		System.out.println("Area: " + this.area);
	}
}
