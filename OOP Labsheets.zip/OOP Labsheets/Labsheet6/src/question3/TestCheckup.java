package question3;

public class TestCheckup {
	public static void main(String[] args) {
		Checkup check = new Checkup();
		check.setHdl(100);
		check.setLdl(50);
		check.setDiastolic(110);
		check.setSystolic(90);
		check.setPatientNo("P1010");
		
		System.out.println("Patient Number: " + check.getPatientNo());
		System.out.println("Blood Pressure: " + check.getSystolic() + "/" + check.getDiastolic());
		System.out.println("HDL: " + check.getHdl());
		System.out.println("LDL: " + check.getLdl());
		check.computeRatio();
		check.explainRatio();
	}
}
