package question3;

public class Checkup {
	private String patientNo;
	private int systolic;
	private int diastolic;
	private int ldl;
	private int hdl;
	
	/* Getters and Setter */
	public String getPatientNo() {
		return patientNo;
	}
	public void setPatientNo(String patientNo) {
		this.patientNo = patientNo;
	}
	public int getSystolic() {
		return systolic;
	}
	public void setSystolic(int systolic) {
		this.systolic = systolic;
	}
	public int getDiastolic() {
		return diastolic;
	}
	public void setDiastolic(int diastolic) {
		this.diastolic = diastolic;
	}
	public int getLdl() {
		return ldl;
	}
	public void setLdl(int ldl) {
		this.ldl = ldl;
	}
	public int getHdl() {
		return hdl;
	}
	public void setHdl(int hdl) {
		this.hdl = hdl;
	}
	
	
	public void computeRatio() {
		double ratio = (double)(ldl) / hdl;
		System.out.println("LDL to HDL ratio: " + ratio);
	}
	
	
	public void explainRatio() {
		System.out.println("LDL is known as good cholesterol and a ratio of 3.5 or lower is considered optimum");
	}
}
