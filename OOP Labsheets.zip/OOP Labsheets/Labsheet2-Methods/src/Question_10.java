/**
 * Labsheet 2
 * Question 10 using methods
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 01/03/2018
 */

import java.util.Scanner;

public class Question_10 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Insert a number to be splitted: ");
		int num = input.nextInt();
		
		convertNumberToWords(num);
		
		input.close();
	}
	
	public static void convertNumberToWords(int num) {
		// Convert to string
		String number = String.valueOf(num);
		String result = "";
		
		for (int  i = 0;  i < number.length(); i++) {
			char c = number.charAt(i);
			
			switch(c) {
				case '0':
					result += "Zero ";
					break;
				case '1':
					result += "One ";
					break;
				case '2':
					result += "Two ";
					break;
				case '3':
					result += "Three ";
					break;
				case '4':
					result += "Four ";
					break;
				case '5':
					result += "Five ";
					break;
				case '6':
					result += "Six ";
					break;
				case '7':
					result += "Seven ";
					break;
				case '8':
					result += "Eight ";
					break;
				case '9':
					result += "Nine ";
					break;
			}
		}
		
		System.out.println(result);
	}
}