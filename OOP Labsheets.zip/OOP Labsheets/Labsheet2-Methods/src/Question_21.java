/**
 * Labsheet 2
 * Question 21 using methods
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 01/03/2018
 */

import java.util.Scanner;

public class Question_21 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num = 0;
		
		System.out.print("Enter a number: ");
		num = input.nextInt();
		
		if (num > 100)
			System.out.println("Wrong Input");
		else
			displayFactor(num);
		
		input.close();
	}
	
	/*
	 * Method to display factors of a number
	 */
	public static void displayFactor(int num) {
		for (int i = 1 ; i <= num; i++) {
			if (num % i == 0)
				System.out.println(i);
		}
	}
}
