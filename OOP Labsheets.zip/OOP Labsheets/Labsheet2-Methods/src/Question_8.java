/**
 * Labsheet 2
 * Question 8 using methods
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 01/03/2018
 */

import java.util.Scanner;

public class Question_8 {
	public static void main(String[] args) {
		int year = 0;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a year: ");
		year = input.nextInt();
		
		if (isLeap(year) )
			System.out.println(year + " is a leap year");
		else
			System.out.println(year + " is not a leap year");
		
		input.close();
	}
	
	/*
	 * Method to check whether a year is leap or not
	 * Leap: return true
	 * Not Leap: return false
	 */
	public static boolean isLeap(int year) {
		// If century year check if divisible by 400 else check if divisible by 4
		if (isCentury(year)) {
			if (year % 400 == 0)
				return true;
			else
				return false;
		}
		else {
			if (year % 4 == 0)
				return true;
			else
				return false;
		}
	}
	
	
	/*
	 * Method to check if a year is century year or not
	 * Century year: return true
	 * Not Century year: return false
	 */
	public static boolean isCentury(int year) {
		if (year % 10 == 0 && year % 100 == 0)
			return true;
		else
			return false;
	}
}
