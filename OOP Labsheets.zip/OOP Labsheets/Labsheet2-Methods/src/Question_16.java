/**
 * Labsheet 2
 * Question 16 using methods
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 01/03/2018
 */

import java.util.Scanner;

public class Question_16 {
	public static void main(String[] args) {
		int n = 0;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Insert last number in the sequence: ");
		n = input.nextInt();
		
		System.out.println("SUM: " + calSum(n));
		System.out.println("PRODUCT: " + calProduct(n));
		System.out.println("AVERAGE: " + calAverage(n));
		
		input.close();
	}
	
	/*
	 * Method to calculate sum of members of a sequence
	 */
	public static int calSum(int n) {
		int sum = 0;
		for (int i = 1; i <= n; i++) {
			sum += i;
		}
		return sum;
	}
	
	/*
	 * Method to calculate product of members of a sequence
	 */
	public static int calProduct(int n) {
		int product = 1;
		for (int i = 1; i <= n; i++) {
			product *= i;
		}
		return product;
	}
	
	/*
	 * Method to calculate average of a sequence
	 */
	public static double calAverage(int n) {
		return (double)(calSum(n)) / n;
	}
}
