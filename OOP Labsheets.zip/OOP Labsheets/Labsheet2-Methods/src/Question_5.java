/**
 * Labsheet 2
 * Question 5 using methods
 * 
 * @author yoven ayassamy
 * @version 1.0
 * 
 * 01/03/2018
 */

import java.util.Scanner;

public class Question_5 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num = 0;
		
		System.out.print("Enter a number: ");
		num = input.nextInt();
		
		if (isPerfectSquare(num)) 
			System.out.println(num + " is a perfect square");
		else
			System.out.println(num + " is a not perfect square");
		
		input.close();
	}	
	
	/*
	 * Method to check if an number is a perfect square or not
	 * returns true if perfect square else returns false
	 */
	public static boolean isPerfectSquare(int  num) {
		// Perform square root
		double sqrt_of_num = Math.sqrt(num);
		
		// check if perfect square or not
		if (num % sqrt_of_num == 0)
			return true;
		else
			return false;
	}
}
