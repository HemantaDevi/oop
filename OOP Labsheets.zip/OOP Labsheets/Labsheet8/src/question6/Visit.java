package question6;

import java.util.Date;

public class Visit {
	private Customer customer;
	private Date date;
	private double serviceExpenses;
	private double productExpenses;
	
	public Visit(String name, Date date) {
		this.customer = new Customer(name);
		this.date = date;
	}
	
	public Visit(Customer customer, Date date) {
		this.customer = customer;
		this.date = date;
	}
	
	public String getName() {
		return this.customer.getName();
	}

	public double getServiceExpenses() {
		return serviceExpenses;
	}

	public void setServiceExpenses(double serviceExpenses) {
		this.serviceExpenses = serviceExpenses;
	}

	public double getProductExpenses() {
		return productExpenses;
	}

	public void setProductExpenses(double productExpenses) {
		this.productExpenses = productExpenses;
	}
	
	public double getTotalExpense() {
		double total = 0.0;
		
		// check if customer is a member
		if (this.customer.isMember()) {
			// Check membership type
			String memberType = this.customer.getMemberType();
			
			// Apply discount on products
			total += this.productExpenses * (1 - DiscountRate.getProductDiscountRate(memberType));
			
			// Apply discount on services
			total += this.serviceExpenses * (1 - DiscountRate.getServiceDiscountRate(memberType));
		}
		else {
			total = this.serviceExpenses + this.productExpenses;
		}
		
		return total;
	}
	
	public String toString() {
		return this.customer.toString() + "Date: " + this.date;
	}
}
