package question6;

import java.util.Date;

public class Test {
	public static void main(String[] args) {
		/* Non Member */
		Visit v1 = new Visit("yoven", new Date());
		System.out.println(v1);
		
		// buy two services
		v1.setServiceExpenses(v1.getServiceExpenses() + 10);
		v1.setServiceExpenses(v1.getServiceExpenses() + 20);
		
		// buy two products
		v1.setProductExpenses(v1.getProductExpenses() + 50);
		v1.setProductExpenses(v1.getProductExpenses() + 30);
		
		// Get total bill for the non member ( No discounts )
		System.out.println("Total Bill For Non Member: " + v1.getTotalExpense());
		System.out.println();
		
		
		
		/* Member */
		Customer c1 = new Customer("sharana");
		c1.setMember(true);
		c1.setMemberType("gold");
		
		Visit v2 = new Visit(c1, new Date());
		System.out.println(v2);
		
		// buy two services
		v2.setServiceExpenses(v2.getServiceExpenses() + 10);
		v2.setServiceExpenses(v2.getServiceExpenses() + 20);
		
		// buy two products
		v2.setProductExpenses(v2.getProductExpenses() + 50);
		v2.setProductExpenses(v2.getProductExpenses() + 30);
		
		// Get total bill for the non member ( No discounts )
		System.out.println("Total Bill For Non Member: " + v2.getTotalExpense());
		System.out.println();
	}
}
