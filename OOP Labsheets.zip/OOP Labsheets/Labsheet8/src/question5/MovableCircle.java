package question5;

public class MovableCircle implements Movable {
	private int radius;
	private MovablePoint center;
	
	public MovableCircle(int x, int y, int xSpeed, int ySpeed, int radius) {
		this.radius = radius;
		this.center = new MovablePoint(x,y,xSpeed, ySpeed);
	}
	
	public String toString() {
		return "Movable Circle @ " + this.center.toString() + " with radius = " + this.radius;
	}
	
	public void moveUp() {
		this.center.y -= this.center.ySpeed;
	}
	
	
	public void moveDown() {
		this.center.y += this.center.ySpeed;
	}
	
	public void moveRight() {
		this.center.x += this.center.xSpeed;
	}
	
	public void moveLeft() {
		this.center.x -= this.center.xSpeed;
	}
}
